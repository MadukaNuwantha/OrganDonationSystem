import React from 'react';
import './common.css';

class LivingDonor extends React.Component{
    render(){
        return(
            <div>
                <div className='bgs'> 
                    
                </div>
            </div>
        );
    }
}

export default LivingDonor;