import React from 'react';
import './common.css';

class GetInvolved extends React.Component{
    render(){
        return(
            <div>
                <div className='bgs'> 

                </div>
            </div>
        );
    }
}

export default GetInvolved;